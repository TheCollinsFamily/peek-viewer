import math
from pathlib import Path

from PySide6.QtCore import Qt, Signal, QUrl, QMimeData
from PySide6.QtGui import QPixmap, QImage, QPainter, QDragEnterEvent, QDropEvent
from PySide6.QtMultimedia import QMediaPlayer, QAudioOutput
from PySide6.QtMultimediaWidgets import QVideoWidget
from PySide6.QtWidgets import (
    QWidget, QLabel, QApplication, QSizePolicy, QFrame,
)
from PIL import Image

from peek.utils import is_image, is_video, fit_size
from peek.resizable import ResizeMixin

_GAP = 2


def _get_aspect(fp):
    """Get width/height aspect ratio of a file."""
    if is_image(fp):
        try:
            img = Image.open(fp)
            w, h = img.size
            img.close()
            return w / max(h, 1)
        except Exception:
            return 1.0
    return 16 / 9


def _compute_rows(aspects, max_cols):
    """Partition images into rows of at most max_cols each."""
    rows = []
    i = 0
    n = len(aspects)
    while i < n:
        rows.append(list(range(i, min(i + max_cols, n))))
        i += max_cols
    return rows


class GridCell(QFrame):
    clicked = Signal(int)

    def __init__(self, index, file_path, aspect, parent=None):
        super().__init__(parent)
        self.index = index
        self.file_path = Path(file_path)
        self.aspect = aspect
        self.setStyleSheet("background-color: black;")

        self._player = None
        self._audio = None

        if is_image(file_path):
            self._setup_image()
        elif is_video(file_path):
            self._setup_video()

    def _setup_image(self):
        label = QLabel(self)
        label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        label.setStyleSheet("border: none;")
        self._label = label

        try:
            pil_img = Image.open(self.file_path)
            pil_img = pil_img.convert("RGBA")
            data = pil_img.tobytes("raw", "RGBA")
            qimg = QImage(data, pil_img.width, pil_img.height, QImage.Format.Format_RGBA8888)
            self._pixmap = QPixmap.fromImage(qimg.copy())
        except Exception:
            self._pixmap = None
            label.setText("Error")
            label.setStyleSheet("color: #ff4444; border: none;")

    def _setup_video(self):
        self._video_widget = QVideoWidget(self)
        self._video_widget.setStyleSheet("border: none;")
        self._video_widget.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)

        self._player = QMediaPlayer(self)
        self._audio = QAudioOutput(self)
        self._audio.setVolume(0.0)
        self._player.setAudioOutput(self._audio)
        self._player.setVideoOutput(self._video_widget)
        self._player.mediaStatusChanged.connect(self._on_status)

        url = QUrl.fromLocalFile(str(self.file_path.resolve()))
        self._player.setSource(url)
        self._player.play()

    def _on_status(self, status):
        if status == QMediaPlayer.MediaStatus.EndOfMedia:
            self._player.setPosition(0)
            self._player.play()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        w, h = self.width(), self.height()

        if hasattr(self, "_label") and self._pixmap:
            self._label.setGeometry(0, 0, w, h)
            fw, fh = fit_size(self._pixmap.width(), self._pixmap.height(), w, h)
            scaled = self._pixmap.scaled(fw, fh, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
            self._label.setPixmap(scaled)

        if hasattr(self, "_video_widget"):
            self._video_widget.setGeometry(0, 0, w, h)

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            parent = self.parentWidget()
            if parent and hasattr(parent, '_resize_mouse_press'):
                from peek.resizable import _detect_edge, _EDGE_NONE
                parent_pos = self.mapTo(parent, event.position().toPoint())
                edge = _detect_edge(parent, parent_pos)
                if edge != _EDGE_NONE or parent_pos.y() <= getattr(parent, '_DRAG_ZONE_HEIGHT', 50):
                    event.ignore()
                    return
            self.clicked.emit(self.index)

    def cleanup(self):
        if self._player:
            self._player.stop()


class GridView(ResizeMixin, QWidget):
    cell_clicked = Signal(int, str)
    closed = Signal()

    def __init__(self, file_paths, max_columns=4, parent=None):
        super().__init__(parent)
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.Window
        )
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        self.setStyleSheet("background-color: #0a0a0a;")
        self.setMinimumSize(400, 300)

        self._file_paths = [Path(p) for p in file_paths]
        self._cells = []
        self._is_fullscreen = False
        self._max_columns = max_columns

        self._resize_init()
        self.setAcceptDrops(True)

        # Read aspect ratios and create cells
        self._aspects = [_get_aspect(fp) for fp in self._file_paths]
        for i, fp in enumerate(self._file_paths):
            cell = GridCell(i, fp, self._aspects[i], self)
            cell.clicked.connect(self._on_cell_clicked)
            self._cells.append(cell)

        # Choose initial window size to fit content with no wasted space
        screen = QApplication.primaryScreen().availableGeometry()
        max_w = int(screen.width() * 0.92)
        max_h = int(screen.height() * 0.92)

        rows = _compute_rows(self._aspects, max_columns)
        # h_ratio = total_height / content_width for justified layout
        total_h_ratio = 0.0
        for row_indices in rows:
            row_aspect_sum = sum(self._aspects[i] for i in row_indices)
            total_h_ratio += 1.0 / max(row_aspect_sum, 0.1)
        # Add gap contribution
        gap_h = _GAP * (len(rows) + 1)

        # Try fitting to width first
        win_w = max_w
        win_h = int(win_w * total_h_ratio + gap_h)
        if win_h > max_h:
            # Too tall, fit to height instead
            win_h = max_h
            win_w = int((win_h - gap_h) / max(total_h_ratio, 0.01))
        win_w = max(400, min(win_w, max_w))
        win_h = max(300, min(win_h, max_h))

        self.resize(win_w, win_h)
        self._center_on_screen()
        self._create_fullscreen_btn()
        self._do_layout()

    def _do_layout(self):
        """Position cells using justified row layout — images fill space perfectly."""
        w = self.width()
        h = self.height()
        if w <= 0 or h <= 0 or not self._cells:
            return

        content_w = w - _GAP * 2
        if content_w <= 0:
            return

        n = len(self._aspects)
        use_cols = 1
        use_score = float('inf')
        for tc in range(1, min(n, self._max_columns) + 1):
            tr = _compute_rows(self._aspects, tc)
            tg = _GAP * (len(tr) + 1)
            nh = tg
            for ri in tr:
                nh += content_w / max(sum(self._aspects[k] for k in ri), 0.1)
            sc = h / max(nh, 1)
            s = abs(math.log(max(sc, 0.01)))
            if s < use_score:
                use_score = s
                use_cols = tc

        rows = _compute_rows(self._aspects, use_cols)

        row_natural_heights = []
        for row_indices in rows:
            row_aspect_sum = sum(self._aspects[i] for i in row_indices)
            row_natural_heights.append(content_w / max(row_aspect_sum, 0.1))

        total_gaps = _GAP * (len(rows) + 1)
        available_h = h - total_gaps
        natural_sum = sum(row_natural_heights)
        scale = available_h / max(natural_sum, 1)

        y = _GAP
        for row_idx, row_indices in enumerate(rows):
            row_h = max(1, int(row_natural_heights[row_idx] * scale))
            row_aspect_sum = sum(self._aspects[i] for i in row_indices)
            x = _GAP
            for j, cell_idx in enumerate(row_indices):
                frac = self._aspects[cell_idx] / max(row_aspect_sum, 0.1)
                cell_w = int(frac * content_w)
                # Last cell in row gets remaining width (avoid rounding gaps)
                if j == len(row_indices) - 1:
                    cell_w = w - _GAP - x
                self._cells[cell_idx].setGeometry(x, y, max(cell_w, 1), row_h)
                self._cells[cell_idx].show()
                x += cell_w + _GAP
            y += row_h + _GAP

    def _center_on_screen(self):
        screen = QApplication.primaryScreen().availableGeometry()
        x = (screen.width() - self.width()) // 2 + screen.x()
        y = (screen.height() - self.height()) // 2 + screen.y()
        self.move(x, y)

    def _on_cell_clicked(self, index):
        if 0 <= index < len(self._file_paths):
            self.cell_clicked.emit(index, str(self._file_paths[index]))

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._reposition_fs_btn()
        self._do_layout()

    def mousePressEvent(self, event):
        if self._resize_mouse_press(event):
            return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if self._resize_mouse_move(event):
            return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        self._resize_mouse_release(event)

    def keyPressEvent(self, event):
        key = event.key()
        if key == Qt.Key.Key_Escape:
            if self._is_fullscreen:
                self._toggle_fullscreen()
            else:
                self.close()
        elif key == Qt.Key.Key_F:
            self._toggle_fullscreen()
        else:
            super().keyPressEvent(event)

    def _toggle_fullscreen(self):
        if self._is_fullscreen:
            self.showNormal()
            self._is_fullscreen = False
        else:
            self.showFullScreen()
            self._is_fullscreen = True

    def dragEnterEvent(self, event: QDragEnterEvent):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()

    def dropEvent(self, event: QDropEvent):
        urls = event.mimeData().urls()
        new_files = []
        for url in urls:
            p = Path(url.toLocalFile())
            if p.is_file() and (is_image(p) or is_video(p)):
                new_files.append(p)
        if new_files:
            self._add_files(new_files)

    def _add_files(self, new_files):
        """Add new files to the grid dynamically."""
        for fp in new_files:
            if fp not in self._file_paths:
                self._file_paths.append(fp)
                a = _get_aspect(fp)
                self._aspects.append(a)
                idx = len(self._cells)
                cell = GridCell(idx, fp, a, self)
                cell.clicked.connect(self._on_cell_clicked)
                self._cells.append(cell)
        self._do_layout()

    def closeEvent(self, event):
        self._unregister_viewer()
        for cell in self._cells:
            cell.cleanup()
        self.closed.emit()
        super().closeEvent(event)
