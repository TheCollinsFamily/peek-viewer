from PySide6.QtCore import Qt, QPoint, QRect, QEvent, Signal
from PySide6.QtGui import QCursor
from PySide6.QtWidgets import QPushButton, QWidget, QFrame

EDGE_SIZE = 20

_EDGE_NONE = 0
_EDGE_LEFT = 1
_EDGE_RIGHT = 2
_EDGE_TOP = 4
_EDGE_BOTTOM = 8


def _detect_edge(widget, pos):
    rect = widget.rect()
    edge = _EDGE_NONE
    if pos.x() <= EDGE_SIZE:
        edge |= _EDGE_LEFT
    elif pos.x() >= rect.width() - EDGE_SIZE:
        edge |= _EDGE_RIGHT
    if pos.y() <= EDGE_SIZE:
        edge |= _EDGE_TOP
    elif pos.y() >= rect.height() - EDGE_SIZE:
        edge |= _EDGE_BOTTOM
    return edge


def _cursor_for_edge(edge):
    if edge in (_EDGE_LEFT, _EDGE_RIGHT):
        return Qt.CursorShape.SizeHorCursor
    if edge in (_EDGE_TOP, _EDGE_BOTTOM):
        return Qt.CursorShape.SizeVerCursor
    if edge in (_EDGE_LEFT | _EDGE_TOP, _EDGE_RIGHT | _EDGE_BOTTOM):
        return Qt.CursorShape.SizeFDiagCursor
    if edge in (_EDGE_RIGHT | _EDGE_TOP, _EDGE_LEFT | _EDGE_BOTTOM):
        return Qt.CursorShape.SizeBDiagCursor
    return Qt.CursorShape.ArrowCursor


_WC_BTN_STYLE = """
    QPushButton {
        background: rgba(255, 255, 255, 0.06);
        color: rgba(255, 255, 255, 0.25);
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 4px;
        font-size: 14px;
        padding: 0;
    }
    QPushButton:hover {
        background: rgba(255, 255, 255, 0.15);
        color: rgba(255, 255, 255, 0.7);
        border-color: rgba(255, 255, 255, 0.25);
    }
"""
_WC_MUTE_STYLE = """
    QPushButton {
        background: rgba(255, 255, 255, 0.06);
        color: rgba(255, 255, 255, 0.12);
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 4px;
        font-size: 14px;
        padding: 0;
        text-decoration: line-through;
    }
    QPushButton:hover {
        background: rgba(255, 255, 255, 0.15);
        color: rgba(255, 255, 255, 0.5);
        border-color: rgba(255, 255, 255, 0.25);
        text-decoration: line-through;
    }
"""
_WC_CLOSE_STYLE = """
    QPushButton {
        background: rgba(255, 255, 255, 0.06);
        color: rgba(255, 255, 255, 0.25);
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 4px;
        font-size: 14px;
        padding: 0;
    }
    QPushButton:hover {
        background: rgba(220, 50, 50, 0.6);
        color: rgba(255, 255, 255, 0.9);
        border-color: rgba(220, 50, 50, 0.5);
    }
"""


class _ButtonBar(QWidget):
    """Transparent floating overlay that renders above native video surfaces."""

    def __init__(self, parent_window):
        super().__init__()
        self._pw = parent_window
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.Tool
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.WindowDoesNotAcceptFocus
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating)
        self.setStyleSheet("background: transparent;")

    def reposition(self):
        pw = self._pw
        if not pw._wc_buttons:
            return
        btn_count = len(pw._wc_buttons)
        bar_w = 28 * btn_count + 4 * (btn_count - 1) + 20
        bar_h = 48
        self.setFixedSize(bar_w, bar_h)

        geo = pw.geometry()
        self.move(geo.x() + geo.width() - bar_w, geo.y())

        x = bar_w - 10
        for btn in reversed(pw._wc_buttons):
            x -= btn.width()
            btn.move(x, 10)
            x -= 4

    def eventFilter(self, obj, event):
        t = event.type()
        if t in (QEvent.Type.Move, QEvent.Type.Resize):
            if not obj.isMinimized():
                self.reposition()
        elif t == QEvent.Type.Close:
            self.close()
        elif t == QEvent.Type.Show:
            self.reposition()
            self.show()
            self.raise_()
        elif t == QEvent.Type.Hide:
            self.hide()
        elif t == QEvent.Type.WindowActivate:
            self.reposition()
            self.show()
            self.raise_()
        elif t == QEvent.Type.WindowDeactivate:
            self.hide()
        elif t == QEvent.Type.WindowStateChange:
            if obj.isMinimized():
                self.hide()
            elif obj.isVisible():
                self.reposition()
                self.show()
                self.raise_()
        return False


class _MergeHighlight(QWidget):
    """Floating transparent overlay that shows a blue glow on merge targets."""

    def __init__(self):
        super().__init__()
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.Tool
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.WindowDoesNotAcceptFocus
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating)
        self.setStyleSheet(
            "background: rgba(88, 166, 255, 0.12); "
            "border: 3px solid rgba(88, 166, 255, 0.8); "
            "border-radius: 6px;"
        )
        self.hide()

    def cover_window(self, target_widget):
        geo = target_widget.geometry()
        self.setGeometry(geo)
        self.show()
        self.raise_()


class ResizeMixin:
    """Mixin that adds edge-resize and title-bar-free window dragging to frameless widgets.

    Subclasses must call `_resize_init()` in __init__ after super().__init__().
    Mouse handlers should call the _resize_* helpers and check return values
    to decide whether to handle the event themselves.
    """

    _all_viewers = []  # class-level registry of open viewer windows

    _merge_overlay = None  # shared singleton overlay

    def _resize_init(self):
        self._resize_edge = _EDGE_NONE
        self._resize_start_pos = None
        self._resize_start_geo = None
        self._move_drag_start = None
        self._merge_target = None
        self._wc_buttons = []
        self._btn_bar = None
        self.setMouseTracking(True)
        ResizeMixin._all_viewers.append(self)
        if ResizeMixin._merge_overlay is None:
            ResizeMixin._merge_overlay = _MergeHighlight()

    def _create_fullscreen_btn(self):
        self._btn_bar = _ButtonBar(self)
        self.installEventFilter(self._btn_bar)
        self._wc_buttons = []
        self._mute_btn = None

        home_btn = QPushButton("⌂", self._btn_bar)
        home_btn.setFixedSize(28, 28)
        home_btn.setStyleSheet(_WC_BTN_STYLE)
        home_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        home_btn.clicked.connect(self._on_home_clicked)
        self._wc_buttons.append(home_btn)

        mute_btn = QPushButton("♪", self._btn_bar)
        mute_btn.setFixedSize(28, 28)
        mute_btn.setStyleSheet(_WC_BTN_STYLE)
        mute_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        mute_btn.clicked.connect(self._on_mute_clicked)
        self._mute_btn = mute_btn
        self._wc_buttons.append(mute_btn)

        minimize_btn = QPushButton("—", self._btn_bar)
        minimize_btn.setFixedSize(28, 28)
        minimize_btn.setStyleSheet(_WC_BTN_STYLE)
        minimize_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        minimize_btn.clicked.connect(self._on_minimize_clicked)
        self._wc_buttons.append(minimize_btn)

        fs_btn = QPushButton("⛶", self._btn_bar)
        fs_btn.setFixedSize(28, 28)
        fs_btn.setStyleSheet(_WC_BTN_STYLE)
        fs_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        fs_btn.clicked.connect(self._toggle_fullscreen)
        self._wc_buttons.append(fs_btn)

        close_btn = QPushButton("✕", self._btn_bar)
        close_btn.setFixedSize(28, 28)
        close_btn.setStyleSheet(_WC_CLOSE_STYLE)
        close_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        close_btn.clicked.connect(self.close)
        self._wc_buttons.append(close_btn)

        self._btn_bar.reposition()
        self._btn_bar.show()

    def _on_home_clicked(self):
        from PySide6.QtWidgets import QApplication
        for w in QApplication.topLevelWidgets():
            if w.__class__.__name__ == 'LauncherWindow':
                w.show()
                w.raise_()
                w.activateWindow()
                break

    def _on_minimize_clicked(self):
        if self._btn_bar:
            self._btn_bar.hide()
        self.showMinimized()

    def _on_mute_clicked(self):
        if hasattr(self, '_audio') and self._audio:
            muted = not self._audio.isMuted()
            self._audio.setMuted(muted)
            if self._mute_btn:
                self._mute_btn.setText("♪" if muted else "♪")
                self._mute_btn.setStyleSheet(_WC_MUTE_STYLE if muted else _WC_BTN_STYLE)

    def _reposition_fs_btn(self):
        if self._btn_bar:
            self._btn_bar.reposition()

    def _resize_mouse_move(self, event):
        """Call from mouseMoveEvent. Returns True if the event was consumed (resize/move in progress)."""
        if self._resize_edge != _EDGE_NONE and self._resize_start_pos is not None:
            self._do_resize(event.globalPosition().toPoint())
            return True

        if self._move_drag_start is not None:
            delta = event.globalPosition().toPoint() - self._move_drag_start
            self.move(self._resize_start_geo.topLeft() + delta)
            self._check_merge_overlap()
            return True

        edge = _detect_edge(self, event.position().toPoint())
        if edge != _EDGE_NONE:
            self.setCursor(_cursor_for_edge(edge))
        else:
            self.unsetCursor()
        return False

    def _check_merge_overlap(self):
        """During drag, highlight any other viewer we overlap significantly."""
        my_geo = self.geometry()
        best = None
        best_area = 0
        for w in ResizeMixin._all_viewers:
            if w is self or not w.isVisible():
                continue
            other_geo = w.geometry()
            overlap = my_geo.intersected(other_geo)
            if not overlap.isEmpty():
                area = overlap.width() * overlap.height()
                # Require at least 10% overlap of the smaller window
                min_area = min(my_geo.width() * my_geo.height(),
                               other_geo.width() * other_geo.height())
                if area > min_area * 0.1 and area > best_area:
                    best = w
                    best_area = area

        # Update highlight overlay
        self._merge_target = best
        overlay = ResizeMixin._merge_overlay
        if overlay:
            if best:
                overlay.cover_window(best)
            else:
                overlay.hide()

    _DRAG_ZONE_HEIGHT = 50

    def _resize_mouse_press(self, event):
        """Call from mousePressEvent. Returns True if a resize or move drag started."""
        if event.button() != Qt.MouseButton.LeftButton:
            return False

        pos = event.position().toPoint()
        edge = _detect_edge(self, pos)

        if edge != _EDGE_NONE:
            self._resize_edge = edge
            self._resize_start_pos = event.globalPosition().toPoint()
            self._resize_start_geo = self.geometry()
            return True

        # Top drag zone acts like a title bar
        if pos.y() <= self._DRAG_ZONE_HEIGHT:
            self._move_drag_start = event.globalPosition().toPoint()
            self._resize_start_geo = self.geometry()
            return True

        return False

    def _resize_mouse_release(self, event):
        """Call from mouseReleaseEvent. Returns True if a resize/move ended."""
        if event.button() == Qt.MouseButton.LeftButton:
            was_active = (self._resize_edge != _EDGE_NONE) or (self._move_drag_start is not None)
            was_moving = self._move_drag_start is not None
            merge_target = self._merge_target

            self._resize_edge = _EDGE_NONE
            self._resize_start_pos = None
            self._resize_start_geo = None
            self._move_drag_start = None
            self._merge_target = None

            # Clear highlight overlay
            if ResizeMixin._merge_overlay:
                ResizeMixin._merge_overlay.hide()

            # Trigger merge
            if was_moving and merge_target:
                self._do_merge(merge_target)
                return True

            return was_active
        return False

    def _get_file_paths(self):
        """Return list of file paths this viewer is showing."""
        # GridView stores all files in _file_paths
        if hasattr(self, '_file_paths'):
            return [str(p) for p in self._file_paths]
        # Single viewers: return just the current file
        if hasattr(self, '_file_list') and self._file_list:
            idx = getattr(self, '_current_index', 0)
            if 0 <= idx < len(self._file_list):
                return [str(self._file_list[idx])]
            return [str(self._file_list[0])]
        return []

    def _do_merge(self, target):
        """Merge this window's files with target's files into a grid."""
        from peek.grid_view import GridView
        from peek.config import config

        my_files = self._get_file_paths()
        target_files = target._get_file_paths()
        combined = target_files + my_files

        if not combined:
            return

        # Remember target geometry for the new grid
        geo = target.geometry()

        # Close both windows
        self.close()
        target.close()

        # Open merged grid
        grid = GridView(combined, max_columns=config.get("grid_max_columns", 4))
        grid.setGeometry(geo)
        grid.show()

    def _unregister_viewer(self):
        """Remove this window from the class-level registry."""
        if self in ResizeMixin._all_viewers:
            ResizeMixin._all_viewers.remove(self)

    def _do_resize(self, global_pos):
        delta = global_pos - self._resize_start_pos
        geo = QRect(self._resize_start_geo)
        min_w = self.minimumWidth()
        min_h = self.minimumHeight()

        if self._resize_edge & _EDGE_LEFT:
            new_left = geo.left() + delta.x()
            if geo.right() - new_left >= min_w:
                geo.setLeft(new_left)
        if self._resize_edge & _EDGE_RIGHT:
            new_right = geo.right() + delta.x()
            if new_right - geo.left() >= min_w:
                geo.setRight(new_right)
        if self._resize_edge & _EDGE_TOP:
            new_top = geo.top() + delta.y()
            if geo.bottom() - new_top >= min_h:
                geo.setTop(new_top)
        if self._resize_edge & _EDGE_BOTTOM:
            new_bottom = geo.bottom() + delta.y()
            if new_bottom - geo.top() >= min_h:
                geo.setBottom(new_bottom)

        self.setGeometry(geo)
